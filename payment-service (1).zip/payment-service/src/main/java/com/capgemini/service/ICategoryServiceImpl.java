package com.capgemini.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.DTO.CategoryDTO;
import com.capgemini.entity.Category;
import com.capgemini.exception.CategoryAlreadyExists;
import com.capgemini.exception.CategoryNotFoundException;
import com.capgemini.repository.ICategoryRepository;

@Service
public class ICategoryServiceImpl implements ICategoryService{
	@Autowired
    private ICategoryRepository categoryRepository;

    @Override
    public List<Category> viewAllCategories() {
        return categoryRepository.findAll();
    }

    @Override
    public Category addCategory(CategoryDTO categoryDTO) throws CategoryAlreadyExists{
    	Optional<Category> existingCategory = categoryRepository.findByName(categoryDTO.getName());

        // If category already exists, throw CategoryAlreadyExists exception
        if (existingCategory.isPresent()) {
            throw new CategoryAlreadyExists("Category with name " + categoryDTO.getName() + " already exists.");
        }

        // If category doesn't exist, proceed to save the new category
        Category category = convertToCategory(categoryDTO);
        return categoryRepository.save(category);
    }

    @Override
    public Category updateCategory(CategoryDTO categoryDTO) throws CategoryNotFoundException{
        Optional<Category> existingCategory = categoryRepository.findById(categoryDTO.getId());
        if (existingCategory.isPresent()) {
            Category category = convertToCategory(categoryDTO);
            return categoryRepository.save(category);
        } else {
            throw new CategoryNotFoundException("Category not found with ID: " + categoryDTO.getId());
        }
    }
    
    @Override
    public Category viewCategory(Long id) throws CategoryNotFoundException {
        return categoryRepository.findById(id)
                .orElseThrow(() -> new CategoryNotFoundException("Category not found with ID: " + id));
    }


    @Override
    public void removeCategory(Long id) throws CategoryNotFoundException{
        Category category = categoryRepository.findById(id)
                .orElseThrow(() -> new CategoryNotFoundException("Category not found with ID: " + id));
        categoryRepository.delete(category);
    }
    
    public Category getCategoryByName(String name) throws CategoryNotFoundException{
        return categoryRepository.findByName(name)
                .orElseThrow(() -> new CategoryNotFoundException("Category not found with name: " + name));
    }

    // Helper method to convert CategoryDTO to Category
    private Category convertToCategory(CategoryDTO categoryDTO) {
        return new Category(categoryDTO.getId(), categoryDTO.getName());
    }
}