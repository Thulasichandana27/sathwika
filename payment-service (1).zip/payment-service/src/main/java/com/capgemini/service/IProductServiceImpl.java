package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.DTO.ProductDTO;

import com.capgemini.entity.Category;
import com.capgemini.entity.Product;
import com.capgemini.exception.ProductNotFoundException;
import com.capgemini.repository.ICategoryRepository;
import com.capgemini.repository.IProductRepository;
//import com.capgemini.client.UserClient;  // Import the UserClient

@Service
public class IProductServiceImpl implements IProductService {

    @Autowired
    private IProductRepository productRepository;

    @Autowired
    private ICategoryRepository categoryRepository;

//    @Autowired
//    private UserClient userClient; // Inject the UserClient to use the FeignClient

    @Override
    public List<Product> viewAllProducts() {
        return productRepository.findAll();
    }

    @Override
    public Product addProduct(ProductDTO productDTO) {
        // Fetch the existing category based on the Category DTO passed from ProductDTO
        Category category = categoryRepository.findById(productDTO.getCategory().getId())
                                              .orElseThrow(() -> new RuntimeException("Category not found"));

        // Create and set the product based on the ProductDTO
        Product product = convertToProduct(productDTO);
        product.setCategory(category); // Set the fetched category to the product

        // Example: Fetch user data via Feign client (if needed)
//        if (productDTO.getUserId() != 0) {  // Check if userId is not 0 (assuming 0 is invalid)
//            Users user = userClient.getUserById(productDTO.getUserId());
//            product.setUserId(user.getUserId()); // Set the userId from the User object returned by Feign
//        }

        // Save the product
        return productRepository.save(product);
    }

    @Override
    public Product updateProduct(ProductDTO productDTO) throws ProductNotFoundException {
        Long productId = productDTO.getProductId();
        if (!productRepository.existsById(productId)) {
            throw new ProductNotFoundException("Product not found with id: " + productId);
        }

        // Find the existing product
        Product existingProduct = productRepository.findById(productId).get();

        // Update product properties based on ProductDTO
        existingProduct.setProductName(productDTO.getProductName());
        existingProduct.setPrice(productDTO.getPrice());
        existingProduct.setQuantity(productDTO.getQuantity());
        existingProduct.setColor(productDTO.getColor());

        // Fetch and set the category (Category is passed via ProductDTO)
        Category category = categoryRepository.findById(productDTO.getCategory().getId())
                                              .orElseThrow(() -> new RuntimeException("Category not found"));
        existingProduct.setCategory(category);

        // Example: Fetch user data via Feign client (if needed)
//        if (productDTO.getUserId() != 0) {
//            Users user = userClient.getUserById(productDTO.getUserId()); // Use Feign client to fetch user data
//            existingProduct.setUserId(user.getUserId()); 
//        }

        // Save and return updated product
        return productRepository.save(existingProduct);
    }

    @Override
    public Product viewProduct(Long id) throws ProductNotFoundException {
        return productRepository.findById(id)
                .orElseThrow(() -> new ProductNotFoundException("Product not found with id: " + id));
    }

    @Override
    public List<Product> viewProductsByCategory(Category category) {
        return productRepository.findByCategory(category);
    }

    @Override
    public Product removeProduct(Long id) throws ProductNotFoundException {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ProductNotFoundException("Product not found with id: " + id));
        productRepository.delete(product);
        return product;
    }

    private Product convertToProduct(ProductDTO productDTO) {
        Product product = new Product();
        product.setProductId(productDTO.getProductId());
        product.setProductName(productDTO.getProductName());
        product.setPrice(productDTO.getPrice());
        product.setQuantity(productDTO.getQuantity());
        product.setColor(productDTO.getColor());
        product.setUserId(productDTO.getUserId());
        return product;
    }
}
