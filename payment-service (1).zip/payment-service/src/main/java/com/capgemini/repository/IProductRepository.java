package com.capgemini.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.entity.Category;
import com.capgemini.entity.Product;

@Repository
public interface IProductRepository extends JpaRepository<Product,Long>{
	 Optional<Product> findByProductId(Long productId);
	 List<Product> findByCategory(Category category);
}
