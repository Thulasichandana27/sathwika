//package com.capgemini.client;
//
//import org.springframework.cloud.openfeign.FeignClient;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//
//import com.capgemini.DTO.Users;
//
//@FeignClient(name = "user-service-1", url = "http://localhost:8282") 
//public interface UserClient {
//	
//	    @GetMapping("/users/userbyid/{id}")
//	    Users getUserById(@PathVariable("id") int userId);
//	}
//
