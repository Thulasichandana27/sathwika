package com.capgemini.exception;


public class CategoryAlreadyExists extends Exception{
   public CategoryAlreadyExists(String message) {
	   super(message);
   }
   public CategoryAlreadyExists() {
   }
}
