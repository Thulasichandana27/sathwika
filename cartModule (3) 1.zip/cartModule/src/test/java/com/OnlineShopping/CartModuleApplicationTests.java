package com.OnlineShopping;

import com.OnlineShopping.client.ProductServiceClient;
import com.OnlineShopping.dto.CartDTO;
import com.OnlineShopping.dto.Product;
import com.OnlineShopping.exceptions.CartNotFoundException;
import com.OnlineShopping.model.Cart;
import com.OnlineShopping.repo.ICartRepository;
import com.OnlineShopping.service.CartServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@ExtendWith(MockitoExtension.class)
public class CartModuleApplicationTests {

    @Mock
    private ICartRepository cartRepo;

    @Mock
    private ProductServiceClient productServiceClient;

    @InjectMocks
    private CartServiceImpl cartService;

    private CartDTO cartDTO;
    private Cart cart;
    private Product product;

    @BeforeEach
    public void setUp() {
        // Mock the CartDTO and Cart object
        cartDTO = new CartDTO();
        cartDTO.setCartId(1);
        cartDTO.setProductId(Arrays.asList(1L, 2L));
        cartDTO.setProductCount(2);
        cartDTO.setUserId(123);
        
        cart = new Cart();
        cart.setCartId(1);
        cart.setProductId(Arrays.asList(1L, 2L));
        cart.setProductCount(2);
        cart.setUserId(123);

        product = new Product();
        //product.setId(1L);
        product.setPrice(100.0);
    }

    
   

    @Test
    public void testCancelCart() throws CartNotFoundException {
        // Mocking cartRepo to return a cart
        when(cartRepo.findById(1)).thenReturn(Optional.of(cart));

        // Call the cancelCart method
        String result = cartService.cancelCart(1);

        // Validate the result
        assertEquals("Cart deleted successfully", result);
        verify(cartRepo, times(1)).delete(cart);
    }

    @Test
    public void testShowAllCarts() {
        // Mocking cartRepo to return a list of carts
        when(cartRepo.findAll()).thenReturn(Arrays.asList(cart));

        // Call the showAllCarts method
        List<Cart> result = cartService.showAllCarts();

        // Validate the result
        assertNotNull(result);
        assertEquals(1, result.size());
        verify(cartRepo, times(1)).findAll();
    }

    @Test
    public void testShowCartById() throws CartNotFoundException {
        // Mocking cartRepo to return a cart
        when(cartRepo.findById(1)).thenReturn(Optional.of(cart));

        // Call the showCartById method
        Cart result = cartService.showCartById(1);

        // Validate the result
        assertNotNull(result);
        assertEquals(1, result.getCartId());
        verify(cartRepo, times(1)).findById(1);
    }

    @Test
    public void testShowCartById_CartNotFound() {
        // Mocking cartRepo to return empty
        when(cartRepo.findById(1)).thenReturn(Optional.empty());

        // Call the showCartById method and expect exception
        assertThrows(CartNotFoundException.class, () -> cartService.showCartById(1));
    }
    
    

}


