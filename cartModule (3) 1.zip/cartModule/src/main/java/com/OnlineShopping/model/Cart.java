package com.OnlineShopping.model;

import java.util.List;
import java.util.Map;

import com.OnlineShopping.dto.Product;

import jakarta.persistence.*;


@Entity
@Table(name="Cart")
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int cartId;
    private int userId;
    private Integer productCount;
    private Double total;
    private List<Long> productId;


//    private Map<Integer, Integer> products;

    public Cart() {
        super();
    }

    public Integer getProductCount() {
        return productCount;
    }

    public void setProductCount(Integer productCount) {
        this.productCount = productCount;
    }

    public Double getTotal() {
        return total;
    }

//    public Map<Integer, Integer> getProducts() {
//        return products;
//    }
//
//    public void setProducts(Map<Integer, Integer> products) {
//        this.products = products;
//    }

    public void setTotal(Double total) {
        this.total = total;
    }
    public int getCartId() {
        return cartId;
    }

    public void setCartId(int cartId) {
        this.cartId = cartId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public List<Long> getProductId() {
        return productId;
    }

    public void setProductId(List<Long> productId) {
        this.productId = productId;
    }
    public Cart(int cartId, int userId, Integer productCount, Double total, List<Long> productId) {
        this.cartId = cartId;
        this.userId = userId;

        this.productCount = productCount;
        this.total = total;
        this.productId = productId;
    }
}