package com.OnlineShopping.repo;

import com.OnlineShopping.dto.CartDTO;
import com.OnlineShopping.model.Cart;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ICartRepository extends JpaRepository<Cart, Integer> {
    // No need to define findAllById, it's already provided by JpaRepository
}