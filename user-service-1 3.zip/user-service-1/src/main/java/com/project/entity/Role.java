package com.project.entity;

public enum Role {
	ADMIN,CUSTOMER,SUPER_ADMIN;
	
	public String getAuthority() {
        return "ROLE_" + name();
    }

}
