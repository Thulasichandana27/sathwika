package com.project.entity;

import jakarta.persistence.*;

import java.util.Set;
 

@Entity
@Table(name="user_tab")
public class Users {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int userId;
 
    @Column(nullable = false, unique = false)
    private String firstName;
 
    @Column(nullable = false, unique = false)
    private String lastName;
 
    @Column(nullable = false, unique = true)
    private String userName;
 
    @Column( unique = false)
    private String password;
 
    @Column(nullable = false, unique = true)
    private String email;
 
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "roletable", joinColumns = @JoinColumn(name = "userId"))
    @Enumerated(EnumType.STRING)
    @Column(name = "roles")
    private Set<Role> roles;
 
	public int getUserId() {
		return userId;
	}
 
	public void setUserId(int userId) {
		this.userId = userId;
	}
 
	public String getFirstName() {
		return firstName;
	}
 
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
 
	public String getLastName() {
		return lastName;
	}
 
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
 
	public String getUserName() {
		return userName;
	}
 
	public void setUserName(String userName) {
		this.userName = userName;
	}
 
	public String getPassword() {
		return password;
	}
 
	public void setPassword(String password) {
		this.password = password;
	}
 
	public String getEmail() {
		return email;
	}
 
	public void setEmail(String email) {
		this.email = email;
	}
 
	public Set<Role> getRoles() {
		return roles;
	}
 
	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}





	public Users(String firstName, String lastName, String userName, String password, String email, Set<Role> roles) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.userName = userName;
		this.password = password;
		this.email = email;
		this.roles = roles;
	}
	public Users() {
		super();
	}
}
 