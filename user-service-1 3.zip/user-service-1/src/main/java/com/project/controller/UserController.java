package com.project.controller;


import com.project.dto.UserRequest;
import com.project.dto.UserResponse;
import com.project.dto.Userdto;
import com.project.exception.UserNotFoundException;
import com.project.jwt.JwtUtil;
import com.project.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping(value="/users")
public class UserController {
 
    @Autowired
    private UserService userService;
 
    @Autowired
    private JwtUtil jwtService;
 
    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private PasswordEncoder passwordEncoder;
 
    @PostMapping(value="/register")
    public ResponseEntity<Userdto> registerUser(@Valid @RequestBody Userdto userdto) {
        userdto.setPassword(passwordEncoder.encode(userdto.getPassword()));
        Userdto createdUser = userService.registerUser(userdto);
        return new ResponseEntity<>(createdUser, HttpStatus.CREATED);
    }
    
    @PostMapping(value = "/login")
    public ResponseEntity<UserResponse> login(@RequestBody UserRequest userRequest) {
        try {
            UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
                    userRequest.getUserName(), userRequest.getPassword()
            );
            var authentication = authenticationManager.authenticate(authenticationToken);
            if (authentication.isAuthenticated()) {
                var token = jwtService.generateToken(userRequest.getUserName());
                return new ResponseEntity<>(new UserResponse("Login Success", token), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new UserResponse("Login Failed", null), HttpStatus.UNAUTHORIZED);
            }
        } catch (BadCredentialsException ex) {
            return new ResponseEntity<>(new UserResponse("Invalid username or password", null), HttpStatus.UNAUTHORIZED);
        } catch (Exception ex) {
            return new ResponseEntity<>(new UserResponse("An unexpected error occurred: " + ex.getMessage(), null), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
 
    @GetMapping("/allusers")
    public ResponseEntity<List<Userdto>> getAllUsers() {
        List<Userdto> users = userService.getAllUsers();
        return new ResponseEntity<>(users, HttpStatus.OK);
    }
 
    @GetMapping("/userbyid/{id}")
    public ResponseEntity<Userdto> getUserById(@PathVariable int id) {
        Optional<Userdto> userDto = userService.getUserById(id);
        return userDto.map(user -> new ResponseEntity<>(user, HttpStatus.OK))
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + id));
    }
 
    @DeleteMapping("remove/{id}") 
    public ResponseEntity<Void> deleteUserById(@PathVariable int id) {
        userService.deleteUserById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
 
    @PutMapping("update/{id}")
    public ResponseEntity<Userdto> updateUser(@PathVariable int id, @Valid @RequestBody Userdto updatedUserDto) {
        Userdto updatedUser = userService.updateUser(id, updatedUserDto);
        return new ResponseEntity<>(updatedUser, HttpStatus.OK);
    }

    @GetMapping("/findbyusername/{userName}")
    public ResponseEntity<Userdto> findByUserName(@PathVariable String userName) {
        Optional<Userdto> userDto = userService.findByUserName(userName);
        return userDto.map(user -> new ResponseEntity<>(user, HttpStatus.OK))
                .orElseThrow(() -> new UserNotFoundException("User not found with username: " + userName));
    }
 
    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<String> handleUserNotFoundException(UserNotFoundException ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }
}
