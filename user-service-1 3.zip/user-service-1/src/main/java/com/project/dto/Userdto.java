package com.project.dto;


import com.project.entity.Role;
import jakarta.validation.constraints.*;


import java.util.Set;


public class Userdto {

	private int userId;

	@NotNull(message = "{user.firstName.required}")
	@Size(min = 2, max = 50, message = "{user.firstName.size}")
	@Pattern(regexp = "^[A-Za-z ]+$", message = "{user.firstName.pattern}")
	private String firstName;

	@NotNull(message = "{user.lastName.required}")
	@Size(min = 2, max = 50, message = "{user.lastName.size}")
	@Pattern(regexp = "^[A-Za-z ]+$", message = "{user.lastName.pattern}")
	private String lastName;

	@NotNull(message = "{user.userName.required}")
	@Size(min = 3, max = 30, message = "{user.userName.size}")
	@Pattern(regexp = "^[A-Za-z0-9_.]+$", message = "{user.userName.pattern}")
	private String userName;

	@NotNull(message = "{user.email.required}")
	@Email(message = "{user.email.valid}")
	private String email;

	@NotNull(message = "{user.password.required}")
	@Size(min = 8, message = "{user.password.size}")
	@Pattern(regexp = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]+$", message = "{user.password.pattern}")
	private String password;

	@NotEmpty(message = "{user.roles.required}")
	private Set<Role> roles;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Set<Role> getRoles() {
		return roles;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}
}
