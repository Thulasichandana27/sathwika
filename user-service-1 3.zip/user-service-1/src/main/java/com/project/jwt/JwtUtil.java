package com.project.jwt;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.concurrent.TimeUnit;

@Component
public class JwtUtil {

    @Value("${app.secretkey}")
    private String secretkey;

    // Generate the Token
    public String generateToken(String subject) {
        var token = Jwts.builder()
                .setSubject(subject)
                .setIssuer("John")
                .setExpiration(new Date(System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(10)))
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setId("jj@123")
                .signWith(SignatureAlgorithm.HS512, secretkey.getBytes())  // Use the secretkey directly as bytes
                .compact();
        return token;
    }

    // Get the Claims
    public Claims getClaims(String token) {
        Claims claims = Jwts.parser()
                .setSigningKey(secretkey.getBytes())  // Use the secretkey directly as bytes
                .build()
                .parseClaimsJws(token)
                .getBody();
        return claims;
    }

    // Get the Subject
    public String getSubject(String token) {
        return getClaims(token).getSubject();
    }

    // Get Token Expiration Date
    public Date getTokenExpiration(String token) {
        return getClaims(token).getExpiration();
    }

    // Check the Expiration of Token
    public boolean isTokenExpired(String token) {
        return getTokenExpiration(token).before(new Date(System.currentTimeMillis()));
    }

    // Validate the token by checking token expiration and checking token username against provided username
    public boolean validateToken(String userName, String token) {
        return getSubject(token).equals(userName) && !isTokenExpired(token);
    }
}
