package com.project.service;


import com.project.dto.Userdto;
import com.project.entity.Users;
import com.project.exception.UserNotFoundException;
import com.project.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public Userdto registerUser(Userdto userDto) {
        Users user = convertToEntity(userDto);
        user = userRepository.save(user);
        return convertToDto(user);
    }

    @Override
    public List<Userdto> getAllUsers() {
        return userRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<Userdto> getUserById(int userId) {
        return userRepository.findById(userId)
                .map(this::convertToDto);
    }

    @Override
    public void deleteUserById(int userId) {
        userRepository.deleteById(userId);
    }

    @Override
    public Userdto updateUser(int userId, Userdto updatedUserDto) {
        Optional<Users> optionalUser = userRepository.findById(userId);
        if (optionalUser.isPresent()) {
            Users user = optionalUser.get();
            user.setFirstName(updatedUserDto.getFirstName());
            user.setLastName(updatedUserDto.getLastName());
            user.setUserName(updatedUserDto.getUserName());
            user.setEmail(updatedUserDto.getEmail());
            user.setPassword(updatedUserDto.getPassword());
            user.setRoles(updatedUserDto.getRoles());
            user = userRepository.save(user);
            return convertToDto(user);
        } else {
            throw new UserNotFoundException("User not found with ID: " + userId);
        }
    }

    @Override
    public Optional<Userdto> login(String userName, String password) {
        Optional<Users> optionalUser = userRepository.findByUserNameAndPassword(userName, password);
        return optionalUser.map(this::convertToDto);
    }

    @Override
    public Optional<Userdto> findByUserName(String userName) {
        return userRepository.findByUserName(userName)
                .map(this::convertToDto);
    }

    private Userdto convertToDto(Users user) {
        Userdto userDto = new Userdto();
        userDto.setUserId(user.getUserId());
        userDto.setFirstName(user.getFirstName());
        userDto.setLastName(user.getLastName());
        userDto.setUserName(user.getUserName());
        userDto.setEmail(user.getEmail());
        userDto.setPassword(user.getPassword());
        userDto.setRoles(user.getRoles());
        return userDto;
    }

    private Users convertToEntity(Userdto userDto) {
        Users user = new Users();
        user.setUserId(userDto.getUserId());
        user.setFirstName(userDto.getFirstName());
        user.setLastName(userDto.getLastName());
        user.setUserName(userDto.getUserName());
        user.setEmail(userDto.getEmail());
        user.setPassword(userDto.getPassword());
        user.setRoles(userDto.getRoles());
        return user;
    }
}
