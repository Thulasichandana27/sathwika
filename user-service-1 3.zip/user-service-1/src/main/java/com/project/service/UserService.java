package com.project.service;

import com.project.dto.Userdto;

import java.util.List;
import java.util.Optional;
 
public interface UserService {
 
    
    Userdto registerUser(Userdto userDto);

    List<Userdto> getAllUsers();
 
    Optional<Userdto> getUserById(int userId);
 
    void deleteUserById(int userId);
 
    Userdto updateUser(int userId, Userdto updatedUserDto);
 
    Optional<Userdto> login(String userName, String password);
 
    Optional<Userdto> findByUserName(String userName);

}

