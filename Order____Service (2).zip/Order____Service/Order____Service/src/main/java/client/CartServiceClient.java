package client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.project1.dto.Cart;

@FeignClient(name="cartModule")
public interface CartServiceClient {
	@GetMapping("/showAllCarts/{cartId}")
	Cart showCartById(@PathVariable int cartId);

}
