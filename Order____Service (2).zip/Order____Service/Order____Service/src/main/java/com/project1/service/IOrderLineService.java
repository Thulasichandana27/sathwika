package com.project1.service;

import java.util.List;

import com.project1.dto.OrderLineDTO;
import com.project1.entity.OrderLine;
import com.project1.exception.OrderLineNotFoundException;



public interface IOrderLineService {
	 OrderLineDTO addOrderLine(OrderLineDTO orderLineDTO);
	    OrderLineDTO viewOrderLine(Long orderLineId) throws OrderLineNotFoundException;
	    List<OrderLineDTO> viewOrderLinesByProductId(Long productId);
	    List<OrderLineDTO> viewOrderLinesByOrderId(Long orderId);
	    OrderLine removeOrderLine(Long orderLineId) throws OrderLineNotFoundException;

}
