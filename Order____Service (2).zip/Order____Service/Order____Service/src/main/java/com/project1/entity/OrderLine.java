package com.project1.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;


@Entity

public class OrderLine {
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "orderline_id")
	 
	    private Long orderLineId;
	 
	 @Column(name = "quantity")
	    private Integer quantity;
	 @Column(name = "product_id")
	    private Long productId;
	 
	 @ManyToOne(fetch = FetchType.LAZY)
	    @JoinColumn(name = "order_id", nullable = false)  // Foreign key to the Order table
	    private Order order;
	 
	public Long getOrderLineId() {
		return orderLineId;
	}
	public void setOrderLineId(Long orderLineId) {
		this.orderLineId = orderLineId;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	 public OrderLine()  {
		 
	 }
	public OrderLine(Long orderLineId, Integer quantity, Long productId) {
		super();
		this.orderLineId = orderLineId;
		this.quantity = quantity;
		this.productId = productId;
	}
	 
}
