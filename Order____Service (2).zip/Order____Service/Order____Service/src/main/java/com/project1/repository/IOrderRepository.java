package com.project1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.project1.entity.Order;
import com.project1.entity.OrderLine;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface IOrderRepository extends JpaRepository<Order, Long> {

    // Custom query methods to fetch by userId, location, or date, for example.
    List<Order> findByUserId(int userId);
    List<Order> findByLocation(String location);
    List<Order> findByOrderDate(LocalDate date);
    List<Order> findByOrderId(Long orderId);

}

