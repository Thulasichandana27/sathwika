package com.project1.service;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import com.project1.dto.OrderDTO;
import com.project1.entity.Order;
import com.project1.entity.OrderLine;
import com.project1.exception.OrderAlreadyExistsException;
import com.project1.exception.OrderNotFoundException;
import com.project1.repository.IOrderRepository;

import client.CartServiceClient;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class IOrderServiceImpl implements IOrderService {

    @Autowired
    private IOrderRepository orderRepository;
    

    

    // Convert Order entity to OrderDTO
    private OrderDTO convertToDTO(Order order) {
        OrderDTO orderDTO = new OrderDTO();
        orderDTO.setOrderId(order.getOrderId());
        orderDTO.setUserId(order.getUserId());
        orderDTO.setOrderStatus(order.getOrderStatus());
        orderDTO.setOrderDate(order.getOrderDate());
        orderDTO.setLocation(order.getLocation());
        orderDTO.setAddressId(order.getAddressId());
        return orderDTO;
    }

    // Convert OrderDTO to Order entity
    private Order convertToEntity(OrderDTO orderDTO) {
        Order order = new Order();
        order.setUserId(orderDTO.getUserId());
        order.setOrderStatus(orderDTO.getOrderStatus());
        order.setOrderDate(orderDTO.getOrderDate());
        order.setLocation(orderDTO.getLocation());
        order.setAddressId(orderDTO.getAddressId());
        return order;
    }

    @Override
    public OrderDTO addOrder(OrderDTO orderDTO) {
        Optional<Order> existingOrder = orderRepository.findById(orderDTO.getOrderId());
        
        if (existingOrder.isPresent()) {
            throw new OrderAlreadyExistsException("An order with ID " + orderDTO.getOrderId() + " already exists.");
        }

        Order order = convertToEntity(orderDTO);
        Order savedOrder = orderRepository.save(order);
        return convertToDTO(savedOrder);
    }

    @Override
    public OrderDTO updateOrder(Long orderId, OrderDTO orderDTO) {
        Optional<Order> orderOpt = orderRepository.findById(orderId);
        
        if (orderOpt.isEmpty()) {
            throw new OrderNotFoundException("Order with ID " + orderId + " not found.");
        }

        Order order = orderOpt.get();
        order.setUserId(orderDTO.getUserId());
        order.setOrderStatus(orderDTO.getOrderStatus());
        order.setOrderDate(orderDTO.getOrderDate());
        order.setLocation(orderDTO.getLocation());
        order.setAddressId(orderDTO.getAddressId());

        Order updatedOrder = orderRepository.save(order);
        return convertToDTO(updatedOrder);
    }

    @Override
    public OrderDTO viewOrder(Long orderId) {
        Optional<Order> orderOpt = orderRepository.findById(orderId);
        
        if (orderOpt.isEmpty()) {
            throw new OrderNotFoundException("Order with ID " + orderId + " not found.");
        }
        
        return convertToDTO(orderOpt.get());
    }

    @Override
    public List<OrderDTO> viewOrdersByUserId(int userId) {
        List<Order> orders = orderRepository.findByUserId(userId);
        return orders.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Override
    public List<OrderDTO> viewOrdersByLocation(String location) {
        List<Order> orders = orderRepository.findByLocation(location);
        return orders.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    @Override
    public List<OrderDTO> viewOrdersByDate(LocalDate orderDate) {
        List<Order> orders = orderRepository.findByOrderDate(orderDate);
        return orders.stream().map(this::convertToDTO).collect(Collectors.toList());
    }
    @Override
    public Order removeOrder(Long id) throws OrderNotFoundException {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new OrderNotFoundException("Product not found with id: " + id));
        orderRepository.delete(order);
        return order;
    }

}
