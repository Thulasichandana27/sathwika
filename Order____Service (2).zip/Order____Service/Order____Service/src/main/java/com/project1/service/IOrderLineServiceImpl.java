package com.project1.service;

import java.util.List;

import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project1.dto.OrderLineDTO;
import com.project1.entity.OrderLine;
import com.project1.exception.OrderLineNotFoundException;
import com.project1.repository.IOrderLineRepository;
@Service
public class IOrderLineServiceImpl implements IOrderLineService {
	@Autowired
    private IOrderLineRepository orderLineRepository;
	
	 private OrderLineDTO convertToDTO(OrderLine orderLine) {
	        OrderLineDTO orderLineDTO = new OrderLineDTO();
	        orderLineDTO.setOrderLineId(orderLine.getOrderLineId());
	        orderLineDTO.setQuantity(orderLine.getQuantity());
	        orderLineDTO.setProductId(orderLine.getProductId());
	        return orderLineDTO;
	    }
	 private OrderLine convertToEntity(OrderLineDTO orderLineDTO) {
//	        OrderLine orderLine = new OrderLine();
//	        orderLine.setQuantity(orderLineDTO.getQuantity());
//	        orderLine.setProductId(orderLineDTO.getProductId());
//	        return orderLine;
		// Assuming orderLineDTO has the order_id field properly set
		 OrderLine orderLine = new OrderLine();
		 orderLine.setOrderLineId(orderLineDTO.getOrderLineId());  // Make sure this is set
		 orderLine.setProductId(orderLineDTO.getProductId());
		 orderLine.setQuantity(orderLineDTO.getQuantity());
		 return orderLine;

//		 IOrderLineService.addOrderLine(orderLine);  // Persist the entity

	    }

	@Override
	public OrderLineDTO addOrderLine(OrderLineDTO orderLineDTO) {
		// TODO Auto-generated method stub
		 OrderLine orderLine = convertToEntity(orderLineDTO);

	        // Save the order line
	        OrderLine savedOrderLine = orderLineRepository.save(orderLine);

	        // Convert saved entity back to DTO
	        return convertToDTO(savedOrderLine);
	}

	@Override
	public OrderLineDTO viewOrderLine(Long orderLineId) throws OrderLineNotFoundException {
		// TODO Auto-generated method stub
		Optional<OrderLine> orderLineOpt = orderLineRepository.findById(orderLineId);

        // If the order line is not found, throw exception
        if (orderLineOpt.isEmpty()) {
            throw new OrderLineNotFoundException("OrderLine with ID " + orderLineId + " not found.");
        }

        // Convert entity to DTO and return
        return convertToDTO(orderLineOpt.get());
	}

	@Override
	public List<OrderLineDTO> viewOrderLinesByProductId(Long productId) {
		// TODO Auto-generated method stub
		 List<OrderLine> orderLines = orderLineRepository.findByProductId(productId);

	        // Convert each OrderLine entity to DTO
	        return orderLines.stream()
	                         .map(this::convertToDTO)
	                         .collect(Collectors.toList());
	}

	@Override
	public List<OrderLineDTO> viewOrderLinesByOrderId(Long orderId) {
		// TODO Auto-generated method stub
		List<OrderLine> orderLines = orderLineRepository.findByOrderLineId(orderId);

        // Convert each OrderLine entity to DTO
        return orderLines.stream()
                         .map(this::convertToDTO)
                         .collect(Collectors.toList());
	}

	@Override
	public OrderLine removeOrderLine(Long orderLineId) throws OrderLineNotFoundException {
		// TODO Auto-generated method stub
        OrderLine orderLine = orderLineRepository.findById(orderLineId)
                .orElseThrow(() -> new OrderLineNotFoundException("OrderLine not found with id: " + orderLineId));

        // Remove the order line from the repository
        orderLineRepository.delete(orderLine);

        // Return the removed order line
        return orderLine;

	}

}
