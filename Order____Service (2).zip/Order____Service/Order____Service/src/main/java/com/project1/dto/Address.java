package com.project1.dto;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;


public class Address {
    
	  // @Id
	   // @GeneratedValue(strategy = GenerationType.IDENTITY)
	   // @Column(name = "address_id")
	    private int addressId;
	    //@Column(name = "street_no")
	    private String streetNo;
	   // @Column(name = "building_name")
	    private String buildingName;
	    private String city;
	    private String state;
	    private String country;
	    private String pincode;
	   // @ManyToOne
	    //@JoinColumn(name = "customer_id")
	   // @JsonBackReference
	    private Users customer;
	 
	    // Getters and Setters
	    public int getAddressId() {
	        return addressId;
	    }
	 
	    public void setAddressId(int addressId) {
	        this.addressId = addressId;
	    }
	 
	    public String getStreetNo() {
	        return streetNo;
	    }
	 
	    public void setStreetNo(String streetNo) {
	        this.streetNo = streetNo;
	    }
	 
	    public String getBuildingName() {
	        return buildingName;
	    }
	 
	    public void setBuildingName(String buildingName) {
	        this.buildingName = buildingName;
	    }
	 
	    public String getCity() {
	        return city;
	    }
	 
	    public void setCity(String city) {
	        this.city = city;
	    }
	 
	    public String getState() {
	        return state;
	    }
	 
	    public void setState(String state) {
	        this.state = state;
	    }
	 
	    public String getCountry() {
	        return country;
	    }
	 
	    public void setCountry(String country) {
	        this.country = country;
	    }
	 
	    public String getPincode() {
	        return pincode;
	    }
	 
	    public void setPincode(String pincode) {
	        this.pincode = pincode;
	    }
	 
	    public Users getCustomer() {
	        return customer;
	    }
	 
	    public void setCustomer(Users customer) {
	        this.customer = customer;
	    }
	    public Address() {
	    	
	    }

		public Address(int addressId, String streetNo, String buildingName, String city, String state, String country,
				String pincode, Users customer) {
			super();
			this.addressId = addressId;
			this.streetNo = streetNo;
			this.buildingName = buildingName;
			this.city = city;
			this.state = state;
			this.country = country;
			this.pincode = pincode;
			this.customer = customer;
		}
	 
}

